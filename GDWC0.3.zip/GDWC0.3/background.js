var settings = new Store("settings", {
    "themepicker": 'light',
    "pagecounter": true,
    "wordcounter": true,
    "gdwclink": true
});

chrome.extension.onRequest.addListener(
	function(request, sender, sendResponse) {
		chrome.pageAction.show(sender.tab.id);
		sendResponse(settings.toObject());
	}
);